#!/usr/bin/env python3
"""
Generate init.sh from blueprint.md technology stack.

Usage:
    python generate_init_script.py --blueprint docs/blueprint.md --output init.sh
    python generate_init_script.py docs/blueprint.md  # Uses defaults
"""

import argparse
import re
from pathlib import Path
from typing import NamedTuple


class TechStack(NamedTuple):
    name: str
    ports: list[int]
    setup_commands: list[str]
    start_command: str
    health_url: str
    category: str  # frontend, backend, database, cache


# Technology detection patterns
TECH_PATTERNS = {
    # Frontend
    "react-vite": TechStack(
        name="React + Vite",
        ports=[5173],
        setup_commands=["npm install --silent 2>/dev/null || npm install"],
        start_command="npm run dev > /tmp/frontend.log 2>&1 &",
        health_url="http://localhost:5173",
        category="frontend"
    ),
    "react-cra": TechStack(
        name="React (CRA)",
        ports=[3000],
        setup_commands=["npm install --silent 2>/dev/null || npm install"],
        start_command="npm start > /tmp/frontend.log 2>&1 &",
        health_url="http://localhost:3000",
        category="frontend"
    ),
    "nextjs": TechStack(
        name="Next.js",
        ports=[3000],
        setup_commands=["npm install --silent 2>/dev/null || npm install"],
        start_command="npm run dev > /tmp/app.log 2>&1 &",
        health_url="http://localhost:3000",
        category="frontend"
    ),
    "vue": TechStack(
        name="Vue.js",
        ports=[5173],
        setup_commands=["npm install --silent 2>/dev/null || npm install"],
        start_command="npm run dev > /tmp/frontend.log 2>&1 &",
        health_url="http://localhost:5173",
        category="frontend"
    ),
    
    # Backend - Python
    "fastapi": TechStack(
        name="FastAPI",
        ports=[8000],
        setup_commands=[
            "[ ! -d 'venv' ] && python3 -m venv venv || true",
            "source venv/bin/activate",
            "pip install -q -r requirements.txt 2>/dev/null || pip install -r requirements.txt"
        ],
        start_command="uvicorn main:app --host 0.0.0.0 --port 8000 --reload > /tmp/backend.log 2>&1 &",
        health_url="http://localhost:8000/health",
        category="backend"
    ),
    "flask": TechStack(
        name="Flask",
        ports=[5000],
        setup_commands=[
            "[ ! -d 'venv' ] && python3 -m venv venv || true",
            "source venv/bin/activate",
            "pip install -q -r requirements.txt"
        ],
        start_command="python app.py > /tmp/backend.log 2>&1 &",
        health_url="http://localhost:5000",
        category="backend"
    ),
    "django": TechStack(
        name="Django",
        ports=[8000],
        setup_commands=[
            "[ ! -d 'venv' ] && python3 -m venv venv || true",
            "source venv/bin/activate",
            "pip install -q -r requirements.txt",
            "python manage.py migrate --run-syncdb 2>/dev/null || true"
        ],
        start_command="python manage.py runserver 0.0.0.0:8000 > /tmp/backend.log 2>&1 &",
        health_url="http://localhost:8000",
        category="backend"
    ),
    
    # Backend - Node
    "express": TechStack(
        name="Express.js",
        ports=[3000],
        setup_commands=["npm install --silent 2>/dev/null || npm install"],
        start_command="npm run dev > /tmp/backend.log 2>&1 &",
        health_url="http://localhost:3000",
        category="backend"
    ),
    "nestjs": TechStack(
        name="NestJS",
        ports=[3000],
        setup_commands=["npm install --silent 2>/dev/null || npm install"],
        start_command="npm run start:dev > /tmp/backend.log 2>&1 &",
        health_url="http://localhost:3000",
        category="backend"
    ),
    
    # Databases
    "postgresql": TechStack(
        name="PostgreSQL",
        ports=[5432],
        setup_commands=[],
        start_command="# PostgreSQL assumed running externally",
        health_url="",
        category="database"
    ),
    "mongodb": TechStack(
        name="MongoDB",
        ports=[27017],
        setup_commands=[],
        start_command="# MongoDB assumed running externally",
        health_url="",
        category="database"
    ),
    "sqlite": TechStack(
        name="SQLite",
        ports=[],
        setup_commands=[],
        start_command="# SQLite - no server needed",
        health_url="",
        category="database"
    ),
    
    # Cache
    "redis": TechStack(
        name="Redis",
        ports=[6379],
        setup_commands=[],
        start_command="# Redis assumed running externally",
        health_url="",
        category="cache"
    ),
}

# Keywords to detect technologies
DETECTION_KEYWORDS = {
    "react-vite": ["react", "vite"],
    "react-cra": ["react", "create-react-app", "cra"],
    "nextjs": ["next.js", "nextjs", "next"],
    "vue": ["vue", "vuejs", "vue.js"],
    "fastapi": ["fastapi", "fast api"],
    "flask": ["flask"],
    "django": ["django"],
    "express": ["express", "expressjs"],
    "nestjs": ["nestjs", "nest.js"],
    "postgresql": ["postgresql", "postgres", "psql"],
    "mongodb": ["mongodb", "mongo"],
    "sqlite": ["sqlite"],
    "redis": ["redis"],
}


def detect_technologies(content: str) -> list[str]:
    """Detect technologies mentioned in blueprint."""
    content_lower = content.lower()
    detected = []
    
    for tech_id, keywords in DETECTION_KEYWORDS.items():
        if any(kw in content_lower for kw in keywords):
            detected.append(tech_id)
    
    # Handle conflicts (e.g., both react-vite and react-cra detected)
    if "react-vite" in detected and "react-cra" in detected:
        # Prefer Vite if both detected
        detected.remove("react-cra")
    
    # If React detected but neither Vite nor CRA, default to Vite
    if any("react" in content_lower for _ in [1]) and not any(t.startswith("react") for t in detected):
        if "nextjs" not in detected:  # Next.js includes React
            detected.append("react-vite")
    
    return detected


def extract_project_name(content: str) -> str:
    """Extract project name from blueprint."""
    # Look for title
    match = re.search(r'^#\s+(.+?)(?:\s+Blueprint|\s+Architecture)?$', content, re.MULTILINE)
    if match:
        return match.group(1).strip()
    
    # Look for "Core Objective" section
    match = re.search(r'Core Objective.*?(?:build|create|develop)\s+(?:a\s+)?(.+?)(?:\.|,|\n)', 
                      content, re.IGNORECASE | re.DOTALL)
    if match:
        return match.group(1).strip()[:50]
    
    return "Project"


def generate_init_script(blueprint_content: str) -> str:
    """Generate init.sh from blueprint content."""
    
    detected = detect_technologies(blueprint_content)
    project_name = extract_project_name(blueprint_content)
    
    # Separate by category
    frontends = [t for t in detected if TECH_PATTERNS.get(t, TechStack("", [], [], "", "", "")).category == "frontend"]
    backends = [t for t in detected if TECH_PATTERNS.get(t, TechStack("", [], [], "", "", "")).category == "backend"]
    databases = [t for t in detected if TECH_PATTERNS.get(t, TechStack("", [], [], "", "", "")).category == "database"]
    caches = [t for t in detected if TECH_PATTERNS.get(t, TechStack("", [], [], "", "", "")).category == "cache"]
    
    # Collect all ports
    all_ports = set()
    for tech_id in detected:
        tech = TECH_PATTERNS.get(tech_id)
        if tech:
            all_ports.update(tech.ports)
    
    # Build tech description
    tech_names = [TECH_PATTERNS[t].name for t in detected if t in TECH_PATTERNS]
    tech_desc = " + ".join(tech_names) if tech_names else "Custom stack"
    
    # Generate script sections
    sections = []
    
    # Header
    sections.append(f'''#!/bin/bash
# {project_name} - Development Environment
# Auto-generated from blueprint.md
# Tech stack: {tech_desc}

set -e

PROJECT_ROOT="$(cd "$(dirname "$0")" && pwd)"
cd "$PROJECT_ROOT"

echo "🔄 Initializing {project_name}..."
echo ""''')
    
    # Cleanup
    if all_ports:
        port_list = " ".join(str(p) for p in sorted(all_ports))
        sections.append(f'''
# ============================================
# CLEANUP
# ============================================
echo "🧹 Cleaning up stale processes..."
for port in {port_list}; do
    lsof -ti:$port 2>/dev/null | xargs kill -9 2>/dev/null || true
done''')
    
    # Backend setup
    if backends:
        backend_tech = TECH_PATTERNS[backends[0]]
        setup_cmds = "\n    ".join(backend_tech.setup_commands)
        
        # Determine directory structure
        if frontends:
            dir_check = '[ -d "backend" ]'
            cd_cmd = 'cd backend'
            cd_back = 'cd "$PROJECT_ROOT"'
        else:
            dir_check = '[ -f "requirements.txt" ] || [ -f "package.json" ]'
            cd_cmd = '# Already in project root'
            cd_back = ''
        
        sections.append(f'''
# ============================================
# BACKEND ({backend_tech.name})
# ============================================
if {dir_check}; then
    echo "🐍 Setting up {backend_tech.name} backend..."
    {cd_cmd}
    {setup_cmds}
    echo "🚀 Starting backend..."
    {backend_tech.start_command}
    {cd_back}
fi''')
    
    # Frontend setup
    if frontends:
        frontend_tech = TECH_PATTERNS[frontends[0]]
        setup_cmds = "\n    ".join(frontend_tech.setup_commands)
        
        # Determine directory structure
        if backends:
            dir_check = '[ -d "frontend" ]'
            cd_cmd = 'cd frontend'
            cd_back = 'cd "$PROJECT_ROOT"'
        else:
            dir_check = '[ -f "package.json" ]'
            cd_cmd = '# Already in project root'
            cd_back = ''
        
        sections.append(f'''
# ============================================
# FRONTEND ({frontend_tech.name})
# ============================================
if {dir_check}; then
    echo "⚛️  Setting up {frontend_tech.name} frontend..."
    {cd_cmd}
    {setup_cmds}
    echo "🚀 Starting frontend..."
    {frontend_tech.start_command}
    {cd_back}
fi''')
    
    # No structure fallback
    sections.append('''
# ============================================
# STRUCTURE CHECK
# ============================================
if [ ! -d "backend" ] && [ ! -d "frontend" ] && [ ! -f "package.json" ] && [ ! -f "requirements.txt" ]; then
    echo "⚠️  No app structure detected yet."
    echo "   This is expected for early implementation sessions."
    echo ""
    echo "📋 Git status:"
    echo "   Branch: $(git branch --show-current 2>/dev/null || echo 'N/A')"
    echo "   Commit: $(git log -1 --oneline 2>/dev/null || echo 'N/A')"
    exit 0
fi''')
    
    # Health check
    sections.append('''
# ============================================
# HEALTH CHECK
# ============================================
echo ""
echo "⏳ Waiting for servers..."
sleep 3''')
    
    # Add health checks for each detected service
    health_checks = []
    for tech_id in frontends + backends:
        tech = TECH_PATTERNS.get(tech_id)
        if tech and tech.health_url:
            health_checks.append(f'''
if curl -s {tech.health_url} > /dev/null 2>&1; then
    echo "   ✓ {tech.name} ready"
else
    echo "   ⚠️  {tech.name} may not be ready"
fi''')
    
    if health_checks:
        sections.append("\n".join(health_checks))
    
    # Status report
    status_lines = []
    for tech_id in frontends:
        tech = TECH_PATTERNS.get(tech_id)
        if tech:
            status_lines.append(f'echo "   Frontend:  {tech.health_url}"')
    
    for tech_id in backends:
        tech = TECH_PATTERNS.get(tech_id)
        if tech:
            status_lines.append(f'echo "   Backend:   {tech.health_url}"')
            if "fastapi" in tech_id:
                status_lines.append(f'echo "   API Docs:  {tech.health_url.replace("/health", "")}/docs"')
    
    status_output = "\n".join(status_lines) if status_lines else 'echo "   App started"'
    
    sections.append(f'''
# ============================================
# STATUS
# ============================================
echo ""
echo "✅ Development environment ready"
echo ""
{status_output}
echo ""
echo "📋 Git status:"
echo "   Branch: $(git branch --show-current 2>/dev/null || echo 'N/A')"
echo "   Commit: $(git log -1 --oneline 2>/dev/null || echo 'N/A')"
echo ""
echo "📝 Session checklist:"
echo "   [ ] Read claude-progress.txt"
echo "   [ ] Read docs/design.md for implementation spec"
echo "   [ ] Check feature_list.json"
echo "   [ ] Pick ONE feature"
echo ""''')
    
    return "\n".join(sections)


def main():
    parser = argparse.ArgumentParser(
        description="Generate init.sh from blueprint.md"
    )
    parser.add_argument(
        "blueprint",
        nargs="?",
        default="docs/blueprint.md",
        help="Path to blueprint.md (default: docs/blueprint.md)"
    )
    parser.add_argument(
        "--output", "-o",
        default="init.sh",
        help="Output path (default: init.sh)"
    )
    
    args = parser.parse_args()
    
    # Read input
    input_path = Path(args.blueprint)
    if not input_path.exists():
        print(f"❌ Error: {input_path} not found")
        return 1
    
    blueprint_content = input_path.read_text()
    
    # Generate
    init_script = generate_init_script(blueprint_content)
    
    # Write output
    output_path = Path(args.output)
    output_path.write_text(init_script)
    output_path.chmod(0o755)
    
    # Report detected tech
    detected = detect_technologies(blueprint_content)
    tech_names = [TECH_PATTERNS[t].name for t in detected if t in TECH_PATTERNS]
    
    print(f"✅ Created {output_path}")
    print(f"   Detected: {', '.join(tech_names) if tech_names else 'No specific tech detected'}")
    
    return 0


if __name__ == "__main__":
    exit(main())

#!/usr/bin/env python3
"""
Validate requirement coverage during implementation.

Checks that features being marked as passing correctly cover their traced requirements.

Usage:
    python validate_traceability.py                    # Check current state
    python validate_traceability.py --update F003     # Update coverage after completing F003
    python validate_traceability.py --report          # Generate coverage report
"""

import argparse
import json
import re
from datetime import datetime, timezone
from pathlib import Path
from typing import Optional


def load_feature_list(path: str = "feature_list.json") -> dict:
    """Load feature list from JSON file."""
    with open(path) as f:
        return json.load(f)


def save_feature_list(data: dict, path: str = "feature_list.json"):
    """Save feature list to JSON file."""
    with open(path, "w") as f:
        json.dump(data, f, indent=2)


def load_requirements(path: str = "docs/requirements.md") -> dict[str, dict]:
    """
    Parse requirements.md to extract all acceptance criteria.
    
    Returns:
        Dict mapping criterion ID to criterion details
    """
    if not Path(path).exists():
        return {}
    
    content = Path(path).read_text()
    criteria = {}
    
    current_req_name = None
    current_req_num = None
    
    for line in content.split("\n"):
        # Requirement header: ### Requirement N: Name
        req_match = re.match(r'^###\s+Requirement\s+(\d+):\s*(.+)', line)
        if req_match:
            current_req_num = req_match.group(1)
            current_req_name = req_match.group(2).strip()
            continue
        
        # Acceptance criterion: N.M WHEN... or just N.M ...
        crit_match = re.match(r'^(\d+\.\d+)\s+(.+)', line.strip())
        if crit_match and current_req_num:
            crit_id = crit_match.group(1)
            crit_text = crit_match.group(2).strip()
            
            criteria[crit_id] = {
                "id": crit_id,
                "requirement": current_req_name,
                "requirement_num": current_req_num,
                "text": crit_text,
                "covered": False,
                "covered_by": []
            }
    
    return criteria


def get_coverage_status(feature_list: dict, requirements: dict) -> dict:
    """
    Calculate current coverage status.
    
    Returns:
        Coverage summary dict
    """
    covered_criteria = set()
    coverage_by_feature = {}
    
    for feature in feature_list.get("features", []):
        if feature.get("passes"):
            reqs = feature.get("requirements_trace", [])
            covered_criteria.update(reqs)
            coverage_by_feature[feature["id"]] = reqs
    
    total = len(requirements) if requirements else feature_list.get("coverage_summary", {}).get("total_requirements", 0)
    covered = len(covered_criteria)
    
    return {
        "total_requirements": total,
        "requirements_covered": covered,
        "coverage_percentage": round(covered / total * 100, 1) if total > 0 else 0,
        "covered_list": sorted(list(covered_criteria)),
        "remaining_list": sorted([r for r in requirements.keys() if r not in covered_criteria]) if requirements else [],
        "coverage_by_feature": coverage_by_feature
    }


def update_feature_coverage(feature_list: dict, feature_id: str, requirements: dict) -> dict:
    """
    Update coverage summary after marking a feature as passing.
    
    Returns:
        Updated feature list
    """
    # Find the feature
    feature = None
    for f in feature_list.get("features", []):
        if f["id"] == feature_id:
            feature = f
            break
    
    if not feature:
        raise ValueError(f"Feature {feature_id} not found")
    
    if not feature.get("passes"):
        # Mark as passing
        feature["passes"] = True
        feature["verified_at"] = datetime.now(timezone.utc).isoformat()
    
    # Recalculate coverage
    feature_list["coverage_summary"] = get_coverage_status(feature_list, requirements)
    feature_list["passing_features"] = sum(1 for f in feature_list["features"] if f.get("passes"))
    feature_list["last_updated"] = datetime.now(timezone.utc).isoformat()
    
    return feature_list


def validate_traceability(feature_list: dict, requirements: dict) -> dict:
    """
    Validate that all requirements are traced to features.
    
    Returns:
        Validation result dict
    """
    # Collect all requirement references from features
    all_traced_reqs = set()
    for feature in feature_list.get("features", []):
        all_traced_reqs.update(feature.get("requirements_trace", []))
    
    # Check for untraced requirements
    all_req_ids = set(requirements.keys())
    untraced = all_req_ids - all_traced_reqs
    
    # Check for invalid references
    invalid_refs = all_traced_reqs - all_req_ids
    
    # Check coverage
    coverage = get_coverage_status(feature_list, requirements)
    
    return {
        "valid": len(untraced) == 0 and len(invalid_refs) == 0,
        "untraced_requirements": sorted(list(untraced)),
        "invalid_references": sorted(list(invalid_refs)),
        "coverage": coverage,
        "message": "All requirements traced and valid" if (len(untraced) == 0 and len(invalid_refs) == 0) else "Traceability issues found"
    }


def generate_coverage_report(feature_list: dict, requirements: dict) -> str:
    """Generate a markdown coverage report."""
    coverage = get_coverage_status(feature_list, requirements)
    validation = validate_traceability(feature_list, requirements)
    
    report = f"""# Coverage Report

Generated: {datetime.now(timezone.utc).strftime("%Y-%m-%d %H:%M UTC")}

## Summary

- **Total Requirements**: {coverage['total_requirements']}
- **Covered**: {coverage['requirements_covered']}
- **Coverage**: {coverage['coverage_percentage']}%

## Features Status

| Feature | Status | Requirements Covered |
|---------|--------|---------------------|
"""
    
    for feature in feature_list.get("features", []):
        status = "✅ Pass" if feature.get("passes") else "⬜ Pending"
        reqs = ", ".join(feature.get("requirements_trace", [])) or "None"
        report += f"| {feature['id']} | {status} | {reqs} |\n"
    
    report += f"""

## Requirements Coverage

### Covered ({len(coverage['covered_list'])})
"""
    for req_id in coverage['covered_list']:
        req = requirements.get(req_id, {})
        report += f"- ✅ {req_id}: {req.get('text', 'N/A')[:50]}...\n"
    
    report += f"""

### Remaining ({len(coverage['remaining_list'])})
"""
    for req_id in coverage['remaining_list']:
        req = requirements.get(req_id, {})
        report += f"- ⬜ {req_id}: {req.get('text', 'N/A')[:50]}...\n"
    
    if validation['untraced_requirements']:
        report += f"""

## ⚠️ Warnings

### Untraced Requirements
These requirements are not assigned to any feature:
"""
        for req_id in validation['untraced_requirements']:
            report += f"- {req_id}\n"
    
    if validation['invalid_references']:
        report += f"""

### Invalid References
These requirement IDs in features don't exist:
"""
        for ref in validation['invalid_references']:
            report += f"- {ref}\n"
    
    return report


def main():
    parser = argparse.ArgumentParser(
        description="Validate requirement traceability and coverage"
    )
    parser.add_argument(
        "--features", "-f",
        default="feature_list.json",
        help="Path to feature_list.json"
    )
    parser.add_argument(
        "--requirements", "-r",
        default="docs/requirements.md",
        help="Path to requirements.md"
    )
    parser.add_argument(
        "--update", "-u",
        metavar="FEATURE_ID",
        help="Update coverage after completing a feature (e.g., F003)"
    )
    parser.add_argument(
        "--report",
        action="store_true",
        help="Generate detailed coverage report"
    )
    parser.add_argument(
        "--output", "-o",
        help="Output file for report (default: stdout)"
    )
    
    args = parser.parse_args()
    
    # Load data
    if not Path(args.features).exists():
        print(f"❌ Error: {args.features} not found")
        return 1
    
    feature_list = load_feature_list(args.features)
    requirements = load_requirements(args.requirements)
    
    # Update mode
    if args.update:
        feature_list = update_feature_coverage(feature_list, args.update, requirements)
        save_feature_list(feature_list, args.features)
        
        coverage = feature_list["coverage_summary"]
        print(f"✅ Updated {args.update}")
        print(f"   Coverage: {coverage['requirements_covered']}/{coverage['total_requirements']} ({coverage['coverage_percentage']}%)")
        
        newly_covered = []
        for f in feature_list["features"]:
            if f["id"] == args.update:
                newly_covered = f.get("requirements_trace", [])
                break
        
        if newly_covered:
            print(f"   Requirements covered: {', '.join(newly_covered)}")
        
        return 0
    
    # Report mode
    if args.report:
        report = generate_coverage_report(feature_list, requirements)
        
        if args.output:
            Path(args.output).write_text(report)
            print(f"✅ Report saved to {args.output}")
        else:
            print(report)
        
        return 0
    
    # Default: validate and show status
    validation = validate_traceability(feature_list, requirements)
    coverage = validation["coverage"]
    
    print("📊 Traceability Status")
    print("=" * 40)
    print(f"Requirements: {coverage['requirements_covered']}/{coverage['total_requirements']} covered ({coverage['coverage_percentage']}%)")
    print(f"Features: {feature_list.get('passing_features', 0)}/{feature_list.get('total_features', 0)} passing")
    print()
    
    if validation["valid"]:
        print("✅ All requirements properly traced")
    else:
        print("⚠️  Traceability issues:")
        if validation["untraced_requirements"]:
            print(f"   Untraced: {', '.join(validation['untraced_requirements'])}")
        if validation["invalid_references"]:
            print(f"   Invalid refs: {', '.join(validation['invalid_references'])}")
    
    print()
    print("Remaining requirements:")
    for req_id in coverage["remaining_list"][:5]:
        req = requirements.get(req_id, {})
        print(f"   {req_id}: {req.get('text', 'N/A')[:40]}...")
    
    if len(coverage["remaining_list"]) > 5:
        print(f"   ... and {len(coverage['remaining_list']) - 5} more")
    
    return 0 if validation["valid"] else 1


if __name__ == "__main__":
    exit(main())

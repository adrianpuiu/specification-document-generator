---
name: spec-to-execution
description: Complete planning-to-implementation pipeline that combines specification-architect (rigorous requirements and design) with long-running-agent (multi-session execution). Use when building complex systems that need both thorough upfront planning AND disciplined incremental implementation across multiple sessions.
---

# Specification to Execution Framework

A complete pipeline from requirements through implementation, combining two proven approaches:

1. **Specification Architect** → Rigorous planning with traceability
2. **Long-Running Agent** → Disciplined multi-session execution

## Core Problem This Solves

Agents working across multiple context windows face a fundamental challenge: each session starts with no memory of what came before. Like engineers working in shifts where each arrives with amnesia, agents must bridge gaps between sessions.

Two critical failure patterns emerge without proper structure:
- **One-shotting**: Agent attempts to build everything at once, runs out of context mid-feature, leaves undocumented mess
- **Premature victory**: Agent sees partial progress and declares the job done

This framework solves both through structured initialization, incremental progress, and disciplined session handoffs.

---

## Common Failure Modes & Solutions

| Problem | Initializer Agent Solution | Coding Agent Solution |
|---|---|---|
| **Declares victory early** | Feature list with ALL features marked `passes: false` | Read feature list at session start, pick ONE failing feature |
| **Leaves broken/undocumented state** | Git repo + progress file initialized | Start by reading progress + git log, run basic e2e test BEFORE new work |
| **Marks features done prematurely** | Feature list is JSON (harder to casually edit) | Test end-to-end as user would before marking `passes: true` |
| **Time wasted figuring out environment** | Write init.sh with dev server setup | Run init.sh first thing every session |
| **Half-implemented features** | Clear scope boundaries in blueprint | ONE feature per session, leave in clean state |
| **Guessing what happened** | Progress file with handover notes | Read progress + git log before ANY work |

---

## When to Use This Skill

Use this integrated skill when:
- Project is complex enough to need formal architecture docs
- Implementation will span 5+ sessions
- Traceability from requirements to code matters
- User wants "do it right" not "do it fast"
- System has multiple components, integrations, or stakeholders

For simpler projects, use `long-running-agent` patterns alone.

---

## The Three-Phase Pipeline

```
┌─────────────────────────────────────────────────────────────────┐
│                    PHASE A: ARCHITECTURE                        │
│                   (Specification Architect)                     │
├─────────────────────────────────────────────────────────────────┤
│  Session A1: Research + Blueprint                               │
│  Session A2: Requirements + Design + Tasks + Validation         │
│                                                                 │
│  Outputs:                                                       │
│    • blueprint.md      - System components and data flow        │
│    • requirements.md   - Acceptance criteria                    │
│    • design.md         - Component specifications               │
│    • tasks.md          - Implementation plan                    │
│    • validation.md     - Traceability matrix                    │
└─────────────────────────────────────────────────────────────────┘
                              │
                              ▼
┌─────────────────────────────────────────────────────────────────┐
│                    PHASE B: CONVERSION                          │
│              (Automatic Feature List Generation)                │
├─────────────────────────────────────────────────────────────────┤
│  Convert tasks.md → feature_list.json                           │
│  Create init.sh from blueprint.md tech stack                    │
│  Initialize claude-progress.txt                                 │
│  Git commit: "Architecture complete, ready for implementation"  │
└─────────────────────────────────────────────────────────────────┘
                              │
                              ▼
┌─────────────────────────────────────────────────────────────────┐
│                    PHASE C: IMPLEMENTATION                      │
│                    (Long-Running Agent)                         │
├─────────────────────────────────────────────────────────────────┤
│  Session C1: F001, F002 (infrastructure)                        │
│  Session C2: F003, F004 (core features)                         │
│  Session C3: F005 (integration)                                 │
│  ...                                                            │
│  Session CN: Final feature, polish                              │
│                                                                 │
│  Each session: BOOT → VERIFY → IMPLEMENT ONE → TEST → HANDOFF   │
└─────────────────────────────────────────────────────────────────┘
```

---

## Project File Structure

After architecture is complete, project contains:

```
project/
├── docs/                          # From Specification Architect
│   ├── blueprint.md               # System architecture
│   ├── requirements.md            # Acceptance criteria
│   ├── design.md                  # Component specs
│   ├── tasks.md                   # Original task breakdown
│   └── validation.md              # Traceability matrix
├── feature_list.json              # Converted from tasks.md (PROTECTED)
├── claude-progress.txt            # Session log + handover notes
├── init.sh                        # Dev environment setup
├── .gitignore
└── [source code directories]
```

---

## Feature List Rules (CRITICAL)

The feature list is the single source of truth for what's done and what remains.

### Protected JSON Format

JSON is used intentionally—models are less likely to inappropriately modify JSON than Markdown.

```json
{
  "id": "F003",
  "category": "functional",
  "description": "User can send a message and receive AI response",
  "steps": [
    "Navigate to chat interface",
    "Type message in input field",
    "Press enter or click send",
    "Verify AI response appears",
    "Verify message appears in history"
  ],
  "dependencies": ["F001", "F002"],
  "requirements_trace": ["1.1", "1.2"],
  "passes": false
}
```

### Modification Rules

| Action | Allowed? |
|---|---|
| Change `passes: false` → `passes: true` | ✅ YES (after verified testing) |
| Change `passes: true` → `passes: false` | ✅ YES (if regression found) |
| Edit `description` | ❌ **UNACCEPTABLE** |
| Edit `steps` | ❌ **UNACCEPTABLE** |
| Remove a feature | ❌ **UNACCEPTABLE** |
| Add a new feature | ⚠️ Only with explicit scope change approval |

**Rationale**: Editing or removing features leads to missing or buggy functionality. The feature list was derived from validated requirements—changing it breaks traceability.

---

## PHASE A: Architecture Sessions

### Session A1: Research + Blueprint

Execute the first three phases of specification-architect:

#### Step 1: Verifiable Research (Phase 0)

```markdown
## Research Protocol

1. Analyze user request for:
   - Core domain (e.g., trading, SaaS, IoT)
   - Scale requirements
   - Integration constraints
   - Technology preferences

2. Use WebSearch to find:
   - Current best practices for the domain
   - Recommended technology stacks
   - Architecture patterns
   - Recent industry developments

3. Use WebFetch to VERIFY each source

4. Produce technology proposal with citations:

# Verifiable Research and Technology Proposal

## 1. Core Problem Analysis
[1-2 sentences on primary technical challenges]

## 2. Verifiable Technology Recommendations
| Technology/Pattern | Rationale & Evidence |
|---|---|
| **[Tech 1]** | [Rationale with citations like [cite:1]] |
| **[Tech 2]** | [Rationale with citations] |

## 3. Browsed Sources
- [1] [URL]
- [2] [URL]
```

**Gate**: "Research complete with [N] verified sources. Proceed to blueprint?"

#### Step 2: Architectural Blueprint (Phase 1)

```markdown
# Architectural Blueprint

## 1. Core Objective
[Single paragraph: what success looks like]

## 2. System Scope and Boundaries
### In Scope
- [Feature 1 that WILL be built]
- [Capability 2 that WILL be implemented]

### Out of Scope
- [Feature that will NOT be built]
- [Integration that will NOT happen]

## 3. Core System Components
| Component Name | Single Responsibility |
|---|---|
| **ComponentA** | [One clear responsibility] |
| **ComponentB** | [One clear responsibility] |

## 4. High-Level Data Flow
[Mermaid diagram showing component interactions]

## 5. Key Integration Points
- **ComponentA ↔ ComponentB**: REST API
- **ComponentB ↔ External**: PostgreSQL
```

**Gate**: "Blueprint complete. Component names locked. Proceed to requirements?"

### Session A2: Requirements + Design + Tasks + Validation

#### Step 3: Requirements (Phase 2)

```markdown
# Requirements Document

## Glossary
- **Term**: Definition

## Requirements

### Requirement 1: [Feature Name]
#### Acceptance Criteria
1.1 WHEN [trigger], THE **ComponentA** SHALL [testable behavior].
1.2 WHEN [condition], THE **ComponentB** SHALL [testable behavior].

### Requirement 2: [Feature Name]
#### Acceptance Criteria
2.1 WHEN [trigger], THE **ComponentA** SHALL [testable behavior].
```

**Gate**: "[N] requirements with [M] acceptance criteria. Proceed to design?"

#### Step 4: Detailed Design (Phase 3)

```markdown
# Design Document

## Component Specifications

### Component: ComponentA
**Purpose**: [From blueprint]
**Location**: `src/component_a/`
**Interface**:
```python
class ComponentA:
    def method_x(self) -> Result:  # Implements Req 1.1
        pass
    
    def method_y(self, data: Input) -> Output:  # Implements Req 1.2, 2.1
        pass
```

### Component: ComponentB
[Same structure]
```

**Gate**: "All components specified. Proceed to task decomposition?"

#### Step 5: Task Decomposition (Phase 4)

```markdown
# Implementation Plan

## Infrastructure
- [ ] 1. Set up project structure
  - [ ] 1.1 Create directory layout
  - [ ] 1.2 Configure build tools
  - _Requirements: None (infrastructure)_

## ComponentA
- [ ] 2. Implement ComponentA core
  - [ ] 2.1 Create ComponentA class in `src/component_a/core.py`
  - [ ] 2.2 Implement method_x()
  - [ ] 2.3 Implement method_y()
  - _Requirements: 1.1, 1.2, 2.1_

## ComponentB
- [ ] 3. Implement ComponentB
  - [ ] 3.1 Create ComponentB class
  - [ ] 3.2 Implement database connection
  - _Requirements: 2.2, 3.1_
```

**Gate**: "[N] tasks created. Proceed to validation?"

#### Step 6: Validation (Phase 5)

```markdown
# Validation Report

## 1. Requirements to Tasks Traceability Matrix

| Requirement | Criterion | Task(s) | Status |
|---|---|---|---|
| 1. Feature A | 1.1 | Task 2.2 | ✓ Covered |
| 1. Feature A | 1.2 | Task 2.3 | ✓ Covered |
| 2. Feature B | 2.1 | Task 2.3 | ✓ Covered |
| 2. Feature B | 2.2 | Task 3.2 | ✓ Covered |

## 2. Coverage Analysis
- **Total Acceptance Criteria**: 4
- **Criteria Covered**: 4
- **Coverage**: 100%

## 3. Final Validation
All criteria traced. Ready for implementation.
```

**Gate**: "Validation complete. 100% traceability. Ready for Phase B conversion?"

---

## PHASE B: Conversion

Convert specification-architect outputs to long-running-agent format.

### Conversion Rules

#### tasks.md → feature_list.json

Each top-level task becomes a feature:

```python
# Conversion mapping:
tasks.md task "2. Implement ComponentA core"
    → feature_list.json feature {
        "id": "F002",
        "category": "functional",  # Infer from task type
        "description": "Implement ComponentA core",
        "steps": [subtasks 2.1, 2.2, 2.3],
        "dependencies": ["F001"],  # From task ordering
        "requirements_trace": ["1.1", "1.2", "2.1"],  # From _Requirements_ tag
        "passes": false
    }
```

#### Category Inference

| Task Type | Category |
|-----------|----------|
| Setup, config, build | infrastructure |
| Auth, validation, encryption | security |
| API, webhook, external | integration |
| Page, component, style | ui |
| Cache, optimize, scale | performance |
| Everything else | functional |

#### Priority Inference

| Condition | Priority |
|-----------|----------|
| Infrastructure/setup tasks | critical |
| Core business logic | critical |
| Integration tasks | high |
| UI tasks | high |
| Enhancement tasks | medium |
| Polish/optional | low |

### Post-Conversion Commit

```bash
git add .
git commit -m "Architecture complete, converted to feature list

Specification Documents:
- blueprint.md: [N] components defined
- requirements.md: [M] acceptance criteria
- design.md: Component specifications
- tasks.md: [P] implementation tasks
- validation.md: 100% traceability

Implementation Artifacts:
- feature_list.json: [P] features, 0 passing
- init.sh: Dev environment for [tech stack]
- claude-progress.txt: Ready for Session C1

Phase A: Complete
Phase B: Complete
Phase C: Ready to begin"
```

---

## PHASE C: Implementation Sessions

### Session Boot Sequence (MANDATORY)

Every implementation session MUST start with this exact sequence:

```bash
# 1. Confirm location
pwd

# 2. Get context from previous sessions
cat claude-progress.txt

# 3. See recent work
git log --oneline -10

# 4. Find next feature to implement
cat feature_list.json | jq '[.[] | select(.passes==false)] | .[0:3]'

# 5. Start development environment
./init.sh

# 6. CRITICAL: Verify existing functionality works
# Run basic e2e test BEFORE any new implementation
```

**Step 6 is non-negotiable.** If the app is broken:
- Fix existing bugs FIRST
- Do NOT start new features on broken foundation
- Document what was broken and how you fixed it

Only after verification passes should you pick ONE feature to implement.

### Typical Session Start Messages

```
[Assistant] I'll start by getting my bearings and understanding the current state.
[Tool Use] <bash - pwd>
[Tool Use] <read - claude-progress.txt>
[Tool Use] <read - feature_list.json>
[Assistant] Let me check the git log to see recent work.
[Tool Use] <bash - git log --oneline -20>
[Assistant] Now let me run init.sh to start the servers.
<Starts the development server>
[Assistant] Running verification test on existing functionality...
<Tests basic e2e flow>
[Assistant] Verification passed. Based on the feature list, the next priority is F007.
Let me check the design spec before implementing.
[Tool Use] <read - docs/design.md>
<Begins implementation of ONE feature>
```

### Feature Implementation Protocol

When implementing a feature:

1. **Check design.md** for component specification
2. **Check requirements.md** for acceptance criteria
3. **Implement** following the design
4. **Test end-to-end** (see Testing Protocol below)
5. **Update feature_list.json** (ONLY change `passes: false` → `passes: true`)
6. **Note** requirement coverage in progress file
7. **Commit** with requirement references

---

## Testing Protocol (CRITICAL)

Features are NOT done until tested end-to-end as a user would.

### The Testing Gap

Common failure: Agent makes code changes, runs unit tests or curl commands, marks feature complete—but feature doesn't actually work when used by a human.

### Testing Requirements by Project Type

#### Web Applications
```markdown
Required Testing:
- [ ] Use browser automation (Puppeteer MCP, Playwright)
- [ ] Navigate as a user would
- [ ] Take screenshots as evidence
- [ ] Test actual UI interactions, not just API calls
- [ ] Verify visual feedback (success messages, error states)

Known Limitations:
- Browser-native alerts/modals may not be visible to automation
- Features using these tend to be buggier—test manually if possible
```

#### APIs
```markdown
Required Testing:
- [ ] Call endpoints with realistic payloads
- [ ] Verify response structure matches spec
- [ ] Verify response data is correct
- [ ] Test error conditions
- [ ] Test edge cases from acceptance criteria
```

#### CLIs
```markdown
Required Testing:
- [ ] Run actual commands (not mocked)
- [ ] Verify stdout matches expected output
- [ ] Test with various input combinations
- [ ] Verify file outputs if applicable
```

### Pre-Implementation Verification

Before starting ANY new feature, run a basic e2e test:

```
For web apps: Start server → Open browser → Perform core action → Verify response
For APIs: Start server → Call health endpoint → Call core endpoint → Verify response
For CLIs: Run help command → Run basic command → Verify output
```

If this fails, fix it before new work.

---

## Clean State Definition

Before ending ANY session, the codebase must be in a **clean state**.

### Clean State Checklist

```markdown
## Session End Verification

Code Quality:
- [ ] No half-implemented features (finish or revert)
- [ ] No commented-out code blocks left behind
- [ ] No TODO comments for "will fix later this session"
- [ ] All new code has appropriate error handling

Functionality:
- [ ] Basic e2e test passes
- [ ] No regressions in previously-passing features
- [ ] New feature works end-to-end (if marked passing)

Documentation:
- [ ] Progress file updated with session summary
- [ ] Git commit made with descriptive message
- [ ] Handover notes for next session

Recovery:
- [ ] If next session starts fresh, they can begin immediately
- [ ] No tribal knowledge required to understand state
- [ ] Git history allows reverting if needed
```

### What "Merge-Ready" Means

Think of each session end as preparing a PR for review:
- Code compiles/runs without errors
- Tests pass
- No debug artifacts left in code
- Commit message explains what and why
- A developer unfamiliar with context could review it

---

## Session End Protocol

### Progress File Update

```markdown
## Session CN - YYYY-MM-DD HH:MM UTC

### Context Inherited
- Last commit: [hash] - "[message]"
- Features passing: X/Y
- Requirements covered: A/B (Z%)

### Work Completed
1. Implemented F007: ComponentA.method_x()
2. Added unit tests for method_x
3. Verified e2e with browser automation

### Requirements Coverage
- ✓ Req 1.1: method_x returns correct result - VERIFIED via e2e test
- ✓ Req 1.2: method_x handles edge cases - VERIFIED via unit tests

### Testing Performed
- [x] ./init.sh runs successfully
- [x] Basic e2e verification passed
- [x] New feature tested with browser automation
- [x] Screenshots captured: /tests/screenshots/session-cn/

### Design Compliance
- Followed interface from design.md section 3.1
- No deviations from specification

### Cumulative Progress
- Features: 7/20 passing (35%)
- Requirements: 12/30 covered (40%)

### Handover Notes
- **Next Priority**: F008: Implement ComponentB.method_y()
- **Design Reference**: docs/design.md section 3.2
- **Blockers**: None
- **Warnings**: Database migrations pending—run before F010
- **Environment State**: Clean, all tests passing
```

### Commit Format

```
feat(F007): implement ComponentA.method_x

Implements requirements 1.1, 1.2 from requirements.md
Follows specification in design.md section 3.1

Testing:
- Unit tests: 5 added, all passing
- E2E test: browser automation verified

Session: C4
Features: 7/20 passing
Coverage: 12/30 requirements (40%)
```

---

## Git Recovery Protocol

When things go wrong, use git to recover:

### Broken State Recovery

```bash
# See what changed
git status
git diff

# If changes are salvageable, commit work-in-progress
git add .
git commit -m "WIP: F007 partial - [description of state]"

# If changes should be abandoned
git checkout -- .
git clean -fd

# If need to revert to last known good state
git log --oneline -10
git revert [bad-commit-hash]
```

### Session Handoff via Git

Progress file + git log together provide full context:
- Progress file: Human-readable summary, next steps, warnings
- Git log: Exact code changes, technical details

Next session reads both to understand state completely.

---

## Quick Reference

### Phase A Checklist (Architecture)

```
Session A1:
[ ] Research with verified sources
[ ] Technology proposal with citations
[ ] Blueprint with components and data flow
[ ] Scope boundaries defined

Session A2:
[ ] Requirements with acceptance criteria
[ ] Design with component specifications
[ ] Tasks with requirement traceability
[ ] Validation with 100% coverage
```

### Phase B Checklist (Conversion)

```
[ ] tasks.md → feature_list.json
[ ] blueprint.md → init.sh
[ ] Initialize claude-progress.txt
[ ] Commit architecture artifacts
[ ] Create docs/ directory with all spec docs
```

### Phase C Checklist (Implementation)

```
Session Start (MANDATORY):
[ ] pwd - confirm location
[ ] Read progress file
[ ] Read git log
[ ] Find next failing feature
[ ] Run init.sh
[ ] VERIFY existing functionality works

Implementation:
[ ] Reference design.md for specs
[ ] Pick ONE feature
[ ] Implement following specification
[ ] Test end-to-end as user would

Session End:
[ ] feature_list.json updated (passes field only)
[ ] Progress file updated with full summary
[ ] Handover notes written
[ ] Git commit with requirement references
[ ] Clean state verified
```

---

## Integration Points

### Referencing Specs During Implementation

```python
# In code comments, reference specs:

class ComponentA:
    """
    Component A - Data Processing Engine
    
    Specification: docs/design.md section 3.1
    Requirements: 1.1, 1.2, 2.1
    """
    
    def method_x(self, data: Input) -> Output:
        """
        Process input data and return result.
        
        Implements: Requirement 1.1
        Acceptance: WHEN data received, SHALL process within 100ms
        """
        pass
```

### Feature List with Traceability

```json
{
  "id": "F007",
  "category": "functional",
  "description": "Implement ComponentA.method_x()",
  "steps": [
    "Create method in src/component_a/core.py",
    "Implement processing logic per design.md 3.1",
    "Add unit tests",
    "Verify Req 1.1 acceptance criteria via e2e test"
  ],
  "requirements_trace": ["1.1"],
  "design_reference": "docs/design.md#component-a",
  "passes": false
}
```

---

## When Things Go Wrong

### Spec Changes During Implementation

If requirements change mid-project:

1. **Update requirements.md** with new/changed criteria
2. **Update validation.md** traceability matrix
3. **Add new features** to feature_list.json (don't edit existing)
4. **Note in progress file**: "Scope change: added Req 4.1"
5. **Commit**: "docs: scope change - added requirement 4.1"

### Feature Doesn't Match Spec

If implementation reveals spec issues:

1. **Document the issue** in progress file immediately
2. **Propose spec amendment** with rationale
3. **Get approval** before deviating from design
4. **Update design.md** with approved changes
5. **Continue implementation** with corrected spec
6. **Note deviation** in commit message

### Session Ends Mid-Feature

If you must end before completing a feature:

1. **Do NOT mark feature as passing**
2. **Commit work-in-progress**: `git commit -m "WIP: F007 partial - [state description]"`
3. **Document in progress file**:
   - What's done
   - What remains
   - Any blockers or gotchas
4. **Ensure code compiles/runs** (even if incomplete)
5. **Next session** continues from WIP, doesn't restart

---

## Files in This Skill

- `SKILL.md` - This file
- `references/phase-protocols.md` - Detailed phase instructions
- `references/conversion-rules.md` - tasks.md → feature_list.json mapping
- `scripts/convert_tasks_to_features.py` - Conversion script
- `scripts/generate_init_script.py` - Init script generator
- `scripts/validate_traceability.py` - Check requirement coverage
- `templates/progress.template.txt` - Progress file template

---

## Example Timeline

| Session | Phase | Focus | Output |
|---------|-------|-------|--------|
| A1 | Architecture | Research + Blueprint | blueprint.md |
| A2 | Architecture | Reqs + Design + Tasks + Validation | 4 docs |
| B | Conversion | Auto-generate implementation artifacts | feature_list.json |
| C1 | Implementation | F001-F002: Infrastructure | Working skeleton |
| C2 | Implementation | F003: Core component A | Req 1.1, 1.2 done |
| C3 | Implementation | F004: Core component B | Req 2.1, 2.2 done |
| C4 | Implementation | F005: Integration | Req 3.1 done |
| ... | Implementation | Continue features | ... |
| CN | Implementation | Final feature + polish | 100% complete |

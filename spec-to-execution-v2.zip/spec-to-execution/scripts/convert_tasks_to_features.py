#!/usr/bin/env python3
"""
Convert tasks.md from specification-architect to feature_list.json for long-running-agent.

Usage:
    python convert_tasks_to_features.py --input docs/tasks.md --output feature_list.json
    python convert_tasks_to_features.py docs/tasks.md  # Uses defaults
"""

import argparse
import json
import re
from dataclasses import dataclass, field, asdict
from datetime import datetime, timezone
from pathlib import Path
from typing import Optional


@dataclass
class Feature:
    id: str
    category: str
    priority: str
    description: str
    steps: list[str]
    dependencies: list[str]
    requirements_trace: list[str]
    design_reference: Optional[str]
    passes: bool = False
    verified_at: Optional[str] = None
    notes: str = ""


@dataclass 
class FeatureList:
    project_name: str
    created: str
    last_updated: str
    total_features: int
    passing_features: int
    source_documents: dict
    categories: dict
    features: list[Feature]
    coverage_summary: dict = field(default_factory=dict)


# Category inference from section headers
CATEGORY_KEYWORDS = {
    "infrastructure": ["infrastructure", "setup", "config", "deploy", "ci/cd", "build"],
    "security": ["auth", "security", "validation", "permission", "role", "jwt", "oauth"],
    "integration": ["api", "integration", "external", "webhook", "third-party", "service"],
    "ui": ["ui", "frontend", "page", "component", "view", "screen", "layout", "style"],
    "performance": ["performance", "cache", "optimize", "speed", "scale", "load"],
    "functional": []  # Default
}


def infer_category(section_header: str, task_title: str) -> str:
    """Infer category from section header and task title."""
    text = f"{section_header} {task_title}".lower()
    
    for category, keywords in CATEGORY_KEYWORDS.items():
        if any(kw in text for kw in keywords):
            return category
    
    return "functional"


def infer_priority(task_number: int, total_tasks: int, category: str, has_critical_reqs: bool) -> str:
    """Infer priority based on task position and category."""
    
    # Infrastructure is always critical
    if category == "infrastructure":
        return "critical"
    
    # Early tasks are critical
    if task_number <= 3:
        return "critical"
    
    # Security early on is critical
    if category == "security" and task_number <= 5:
        return "critical"
    
    # Tasks with critical requirements
    if has_critical_reqs:
        return "high"
    
    # Integration and UI are high priority
    if category in ["integration", "ui"]:
        return "high"
    
    # Late tasks are lower priority
    if task_number > total_tasks * 0.75:
        return "low"
    
    return "medium"


def parse_requirements_tag(text: str) -> list[str]:
    """Extract requirements from _Requirements: X.Y, X.Z_ tag."""
    match = re.search(r'_Requirements?:\s*([^_]+)_', text, re.IGNORECASE)
    if not match:
        return []
    
    content = match.group(1).strip()
    if content.lower() in ["none", "n/a", "-"]:
        return []
    
    # Parse comma-separated requirement IDs
    reqs = []
    for part in content.split(","):
        part = part.strip()
        if part:
            reqs.append(part)
    
    return reqs


def parse_tasks_md(content: str) -> tuple[list[dict], str]:
    """
    Parse tasks.md content into structured task list.
    
    Returns:
        (tasks, project_name)
    """
    tasks = []
    current_section = "General"
    current_task = None
    project_name = "Project"
    
    lines = content.split("\n")
    
    for line in lines:
        line_stripped = line.strip()
        
        # Extract project name from title
        if line_stripped.startswith("# "):
            title = line_stripped[2:].strip()
            if "implementation" in title.lower():
                project_name = title.replace("Implementation Plan", "").strip()
            else:
                project_name = title
        
        # Section header
        elif line_stripped.startswith("## "):
            current_section = line_stripped[3:].strip()
        
        # Main task: - [ ] N. Title
        elif re.match(r'^-\s*\[\s*\]\s*\d+\.', line_stripped):
            if current_task:
                tasks.append(current_task)
            
            match = re.match(r'^-\s*\[\s*\]\s*(\d+)\.\s*(.+)', line_stripped)
            if match:
                task_num = int(match.group(1))
                task_title = match.group(2).strip()
                
                current_task = {
                    "number": task_num,
                    "title": task_title,
                    "section": current_section,
                    "subtasks": [],
                    "requirements": []
                }
        
        # Subtask: - [ ] N.M Subtask
        elif current_task and re.match(r'^-\s*\[\s*\]\s*\d+\.\d+', line_stripped):
            match = re.match(r'^-\s*\[\s*\]\s*\d+\.\d+\s*(.+)', line_stripped)
            if match:
                subtask = match.group(1).strip()
                current_task["subtasks"].append(subtask)
        
        # Requirements tag
        elif current_task and "_Requirements" in line_stripped:
            reqs = parse_requirements_tag(line_stripped)
            current_task["requirements"] = reqs
    
    # Don't forget last task
    if current_task:
        tasks.append(current_task)
    
    return tasks, project_name


def infer_dependencies(task: dict, all_tasks: list[dict], infra_task_ids: list[str]) -> list[str]:
    """Infer dependencies for a task."""
    deps = []
    category = infer_category(task["section"], task["title"])
    task_num = task["number"]
    
    # Non-infrastructure tasks depend on all infrastructure
    if category != "infrastructure" and infra_task_ids:
        deps.extend(infra_task_ids)
    
    # Security tasks that aren't first depend on earlier security
    if category == "security":
        for prev_task in all_tasks:
            if prev_task["number"] < task_num:
                prev_cat = infer_category(prev_task["section"], prev_task["title"])
                if prev_cat == "security":
                    deps.append(f"F{prev_task['number']:03d}")
    
    # UI tasks depend on their functional counterparts
    if category == "ui":
        # Look for related functional tasks
        task_keywords = task["title"].lower().split()
        for prev_task in all_tasks:
            if prev_task["number"] < task_num:
                prev_cat = infer_category(prev_task["section"], prev_task["title"])
                if prev_cat == "functional":
                    # Simple keyword matching
                    prev_keywords = prev_task["title"].lower().split()
                    if any(kw in prev_keywords for kw in task_keywords if len(kw) > 3):
                        deps.append(f"F{prev_task['number']:03d}")
    
    return list(set(deps))  # Remove duplicates


def generate_design_reference(task: dict, section: str) -> Optional[str]:
    """Generate design.md reference based on task section."""
    if section.lower() in ["infrastructure", "setup", "general"]:
        return None
    
    # Convert section name to anchor format
    anchor = section.lower().replace(" ", "-")
    anchor = re.sub(r'[^a-z0-9-]', '', anchor)
    
    return f"docs/design.md#{anchor}"


def convert_tasks_to_features(tasks_content: str, requirements_content: Optional[str] = None) -> FeatureList:
    """Convert parsed tasks to feature list."""
    
    tasks, project_name = parse_tasks_md(tasks_content)
    total_tasks = len(tasks)
    
    # First pass: identify infrastructure tasks
    infra_task_ids = []
    for task in tasks:
        category = infer_category(task["section"], task["title"])
        if category == "infrastructure":
            infra_task_ids.append(f"F{task['number']:03d}")
    
    # Collect all requirements for coverage tracking
    all_requirements = set()
    for task in tasks:
        all_requirements.update(task["requirements"])
    
    # Convert tasks to features
    features = []
    for task in tasks:
        category = infer_category(task["section"], task["title"])
        has_critical_reqs = any(req.startswith("1.") for req in task["requirements"])
        
        feature = Feature(
            id=f"F{task['number']:03d}",
            category=category,
            priority=infer_priority(task["number"], total_tasks, category, has_critical_reqs),
            description=task["title"],
            steps=task["subtasks"] if task["subtasks"] else [f"Implement {task['title']}"],
            dependencies=infer_dependencies(task, tasks, infra_task_ids),
            requirements_trace=task["requirements"],
            design_reference=generate_design_reference(task, task["section"]),
            passes=False,
            verified_at=None,
            notes=""
        )
        features.append(feature)
    
    now = datetime.now(timezone.utc).isoformat()
    
    return FeatureList(
        project_name=project_name,
        created=now,
        last_updated=now,
        total_features=len(features),
        passing_features=0,
        source_documents={
            "blueprint": "docs/blueprint.md",
            "requirements": "docs/requirements.md",
            "design": "docs/design.md",
            "tasks": "docs/tasks.md",
            "validation": "docs/validation.md"
        },
        categories={
            "functional": "Core user-facing functionality",
            "integration": "External system connections",
            "ui": "User interface and experience",
            "performance": "Speed and scalability requirements",
            "security": "Authentication, authorization, data protection",
            "infrastructure": "Deployment, monitoring, logging"
        },
        features=features,
        coverage_summary={
            "total_requirements": len(all_requirements),
            "requirements_covered": 0,
            "coverage_percentage": 0,
            "covered_list": [],
            "remaining_list": sorted(list(all_requirements))
        }
    )


def feature_list_to_dict(fl: FeatureList) -> dict:
    """Convert FeatureList to JSON-serializable dict."""
    result = asdict(fl)
    # Convert Feature objects to dicts
    result["features"] = [asdict(f) for f in fl.features]
    return result


def main():
    parser = argparse.ArgumentParser(
        description="Convert tasks.md to feature_list.json"
    )
    parser.add_argument(
        "input",
        nargs="?",
        default="docs/tasks.md",
        help="Path to tasks.md (default: docs/tasks.md)"
    )
    parser.add_argument(
        "--output", "-o",
        default="feature_list.json",
        help="Output path (default: feature_list.json)"
    )
    parser.add_argument(
        "--requirements", "-r",
        help="Path to requirements.md for coverage tracking"
    )
    
    args = parser.parse_args()
    
    # Read input
    input_path = Path(args.input)
    if not input_path.exists():
        print(f"❌ Error: {input_path} not found")
        return 1
    
    tasks_content = input_path.read_text()
    
    # Read requirements if provided
    requirements_content = None
    if args.requirements:
        req_path = Path(args.requirements)
        if req_path.exists():
            requirements_content = req_path.read_text()
    
    # Convert
    feature_list = convert_tasks_to_features(tasks_content, requirements_content)
    
    # Write output
    output_path = Path(args.output)
    with open(output_path, "w") as f:
        json.dump(feature_list_to_dict(feature_list), f, indent=2)
    
    print(f"✅ Created {output_path}")
    print(f"   Features: {feature_list.total_features}")
    print(f"   Requirements tracked: {feature_list.coverage_summary['total_requirements']}")
    
    # Print category breakdown
    categories = {}
    for f in feature_list.features:
        categories[f.category] = categories.get(f.category, 0) + 1
    
    print(f"   Categories:")
    for cat, count in sorted(categories.items()):
        print(f"      {cat}: {count}")
    
    return 0


if __name__ == "__main__":
    exit(main())

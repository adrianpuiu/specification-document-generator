# Phase Protocols Reference

Detailed protocols for each phase of the spec-to-execution pipeline.

## Phase A: Architecture Sessions

### A1: Research + Blueprint (Estimated: 1 session)

#### Research Protocol

**Time allocation**: 40% of session

1. **Analyze the Request**
   ```
   Extract:
   - Domain (e.g., e-commerce, fintech, IoT)
   - Scale requirements (users, data volume, throughput)
   - Integration constraints (existing systems, APIs)
   - Technology preferences (languages, frameworks)
   - Compliance requirements (GDPR, HIPAA, SOC2)
   ```

2. **Execute Web Research**
   ```
   Search queries to run:
   - "[domain] architecture best practices 2024"
   - "[domain] technology stack recommendations"
   - "[framework] vs [alternative] production"
   - "[requirement] implementation patterns"
   ```

3. **Verify Every Source**
   ```
   For each search result:
   1. WebFetch the URL
   2. Confirm the claim exists in the actual content
   3. Note the specific section/quote
   4. Add to sources list with index
   ```

4. **Produce Technology Proposal**
   ```markdown
   # Technology Proposal
   
   ## Core Problem Analysis
   [1-2 sentences]
   
   ## Recommendations
   | Technology | Rationale |
   |------------|-----------|
   | FastAPI | High performance async framework suitable for 10k req/s [cite:1] |
   | PostgreSQL | ACID compliance required for financial data [cite:2] |
   
   ## Sources
   - [1] https://... (verified via WebFetch)
   - [2] https://... (verified via WebFetch)
   ```

**Approval Gate**: "Research complete with [N] verified sources. Proceed to blueprint?"

#### Blueprint Protocol

**Time allocation**: 60% of session

1. **Define Core Objective**
   - Single paragraph
   - What does success look like?
   - Who are the users?

2. **Set Scope Boundaries**
   ```markdown
   ### In Scope
   - User authentication with email/password
   - REST API for mobile clients
   - PostgreSQL database
   
   ### Out of Scope
   - OAuth/social login (future phase)
   - GraphQL API
   - Real-time features (WebSocket)
   ```

3. **Identify Components**
   - Each component has ONE responsibility
   - Use clear, consistent names
   - These names are LOCKED for all future documents

4. **Map Data Flow**
   ```mermaid
   graph TD
       User[User/Client] --> API[API Gateway]
       API --> Auth[Auth Service]
       API --> Core[Core Service]
       Core --> DB[(Database)]
       Core --> Cache[(Redis Cache)]
   ```

5. **Define Integration Points**
   - Protocol for each connection (REST, gRPC, SQL)
   - Authentication method
   - Data format (JSON, protobuf)

**Approval Gate**: "Blueprint complete. [N] components defined. Proceed to requirements?"

---

### A2: Requirements + Design + Tasks + Validation (Estimated: 1 session)

#### Requirements Protocol

**Time allocation**: 25% of session

1. **Create Glossary**
   - Define all domain terms
   - Define all technical terms
   - Ensure consistent vocabulary

2. **Write Requirements**
   ```markdown
   ### Requirement 1: User Registration
   #### Acceptance Criteria
   1.1 WHEN user submits valid email and password,
       THE **AuthService** SHALL create a new user record
       AND return a JWT token.
   
   1.2 WHEN user submits invalid email format,
       THE **AuthService** SHALL return error 400
       WITH message "Invalid email format".
   ```

3. **Rules for Acceptance Criteria**
   - Use WHEN/THE/SHALL format
   - Reference specific component (from blueprint)
   - Make it testable (specific behavior, not vague)
   - One behavior per criterion

**Approval Gate**: "[N] requirements, [M] acceptance criteria. Proceed to design?"

#### Design Protocol

**Time allocation**: 30% of session

1. **Specify Each Component**
   ```markdown
   ### Component: AuthService
   
   **Purpose**: Handle user authentication and authorization
   
   **Location**: `src/services/auth/`
   
   **Dependencies**:
   - Database (PostgreSQL)
   - JWTUtils
   
   **Interface**:
   ```python
   class AuthService:
       async def register(self, email: str, password: str) -> User:
           """Create new user. Implements Req 1.1"""
           
       async def login(self, email: str, password: str) -> Token:
           """Authenticate user. Implements Req 2.1"""
           
       async def validate_token(self, token: str) -> Claims:
           """Validate JWT. Implements Req 2.2"""
   ```
   
   **Data Models**:
   ```python
   class User:
       id: UUID
       email: str
       password_hash: str
       created_at: datetime
   ```
   ```

2. **Ensure Complete Coverage**
   - Every acceptance criterion appears in at least one interface
   - Add "Implements Req X.Y" comments

**Approval Gate**: "All [N] components specified. Proceed to tasks?"

#### Task Decomposition Protocol

**Time allocation**: 25% of session

1. **Create Task Hierarchy**
   ```markdown
   ## Infrastructure
   - [ ] 1. Project setup
     - [ ] 1.1 Create directory structure
     - [ ] 1.2 Configure Poetry/package.json
     - [ ] 1.3 Set up linting (ruff/eslint)
     - _Requirements: None_
   
   ## AuthService
   - [ ] 2. Implement AuthService
     - [ ] 2.1 Create AuthService class
     - [ ] 2.2 Implement register() method
     - [ ] 2.3 Implement login() method
     - [ ] 2.4 Add input validation
     - _Requirements: 1.1, 1.2, 2.1_
   ```

2. **Task Rules**
   - Each task is 1-4 hours of work
   - Subtasks are specific actions
   - Every task has `_Requirements:_` tag
   - Infrastructure tasks have `_Requirements: None_`

**Approval Gate**: "[P] tasks created. Proceed to validation?"

#### Validation Protocol

**Time allocation**: 20% of session

1. **Build Traceability Matrix**
   - List ALL acceptance criteria from requirements.md
   - For each criterion, find implementing task(s)
   - Mark status: Covered or MISSING

2. **Check for Gaps**
   ```markdown
   ## Coverage Analysis
   
   ### Covered Criteria
   - 1.1 → Task 2.2
   - 1.2 → Task 2.4
   - 2.1 → Task 2.3
   
   ### Missing Criteria
   [MUST BE EMPTY]
   
   ### Invalid References
   [MUST BE EMPTY]
   ```

3. **Fix Any Issues**
   - Missing criteria → Add task
   - Invalid reference → Fix task
   - Re-validate until 100%

**Final Gate**: "Validation complete. 100% coverage. Ready for Phase B?"

---

## Phase B: Conversion

### Automatic Conversion Protocol

Run after Phase A approval:

```bash
# 1. Convert tasks to features
python scripts/convert_tasks_to_features.py \
    --input docs/tasks.md \
    --output feature_list.json \
    --requirements docs/requirements.md

# 2. Generate init script
python scripts/generate_init_script.py \
    --blueprint docs/blueprint.md \
    --output init.sh

# 3. Initialize progress file
cat > claude-progress.txt << EOF
# Claude Progress Log

## Project: [from blueprint]
## Repository: local
## Primary Tech: [from blueprint]

---

## Phase A Complete - [timestamp]

### Architecture Documents Created
- blueprint.md: [N] components
- requirements.md: [M] acceptance criteria
- design.md: Component specifications
- tasks.md: [P] tasks
- validation.md: 100% traceability

### Conversion Complete
- feature_list.json: [P] features generated
- init.sh: Development environment configured

### Ready for Phase C
- First priority: F001, F002 (infrastructure)
- All features start at passes: false

---
EOF

# 4. Commit
git add .
git commit -m "Architecture complete, ready for implementation"
```

---

## Phase C: Implementation Sessions

### Enhanced Session Start

```bash
# 1. Standard context loading
pwd
cat claude-progress.txt
cat feature_list.json | head -50
git log --oneline -10

# 2. Load relevant architecture docs
# For infrastructure tasks:
cat docs/blueprint.md

# For component implementation:
cat docs/design.md | grep -A 50 "Component: [ComponentName]"

# For specific requirements:
cat docs/requirements.md | grep -A 10 "Requirement [N]"

# 3. Start environment
./init.sh
```

### Implementation Workflow

```
1. SELECT feature from feature_list.json where passes=false
   
2. LOAD relevant spec sections:
   - design.md: Implementation specification
   - requirements.md: Acceptance criteria to satisfy
   
3. IMPLEMENT following the design spec exactly
   
4. TEST against each acceptance criterion:
   - Run unit tests
   - Manual verification of each criterion
   - Document test results
   
5. UPDATE artifacts:
   - feature_list.json: passes=true, verified_at=now
   - claude-progress.txt: Session summary with requirements covered
   
6. COMMIT with traceability:
   git commit -m "feat(F00X): [description]
   
   Implements requirements: X.Y, X.Z
   Design reference: docs/design.md section N
   
   Session: CN"
```

### Session End Template

```markdown
## Session C[N] - YYYY-MM-DD HH:MM UTC

### Context Inherited
- Last commit: [hash]
- Features passing: X/Y
- Requirements covered: A/B

### Session Goal
- F00X: [Feature description]

### Work Completed
1. Implemented [component].[method]
2. Added unit tests
3. Verified acceptance criteria

### Requirements Coverage This Session
- ✓ Req X.Y: [criterion] - VERIFIED
- ✓ Req X.Z: [criterion] - VERIFIED

### Design Compliance
- Followed: docs/design.md section N
- Deviations: None (or document any)

### Testing Performed
- [x] Unit tests pass
- [x] Integration tests pass
- [x] Manual e2e verification
- [x] Acceptance criteria X.Y verified
- [x] Acceptance criteria X.Z verified

### Files Changed
- `src/[path]` - [description]
- `tests/[path]` - [description]

### Commits Made
- [hash] - "feat(F00X): [message]"

### Cumulative Progress
- Features: X/Y passing
- Requirements: A/B covered

### Handover Notes
- **Next Priority**: F00[X+1]
- **Blockers**: None
- **Environment**: Clean
```

# Conversion Rules Reference

How to transform specification-architect outputs into long-running-agent artifacts.

## tasks.md → feature_list.json

### Structure Mapping

```
tasks.md                          feature_list.json
─────────────────────────────────────────────────────────
## Section Header                 (used for grouping)
- [ ] 1. Task Title               → id: "F001"
  - [ ] 1.1 Subtask 1            → steps[0]
  - [ ] 1.2 Subtask 2            → steps[1]
  - _Requirements: X.Y, X.Z_     → requirements_trace
```

### Field Mappings

| tasks.md | feature_list.json | Transform |
|----------|-------------------|-----------|
| Task number (1, 2, 3...) | `id` | Format as "F001", "F002", etc. |
| Task title | `description` | Copy directly |
| Subtasks (1.1, 1.2...) | `steps` | Array of strings |
| `_Requirements: X.Y_` | `requirements_trace` | Parse comma-separated |
| Section header | `category` | Map to category (see below) |
| Task order | `dependencies` | Earlier tasks are dependencies |
| N/A | `priority` | Infer from category/order |
| N/A | `passes` | Always `false` initially |
| N/A | `verified_at` | Always `null` initially |

### Category Inference

Map section headers to categories:

| Section Header Contains | Category |
|------------------------|----------|
| Infrastructure, Setup, Config | `infrastructure` |
| Auth, Security, Validation | `security` |
| API, Integration, External, Webhook | `integration` |
| UI, Frontend, Page, Component | `ui` |
| Performance, Cache, Optimize | `performance` |
| Database, Model, Schema | `functional` |
| (default) | `functional` |

### Priority Inference

| Condition | Priority |
|-----------|----------|
| Category = infrastructure | `critical` |
| Category = security AND early task | `critical` |
| Task number ≤ 3 | `critical` |
| Category = integration | `high` |
| Category = ui | `high` |
| Requirements_trace contains critical reqs | `high` |
| Task number > 75% of total | `low` |
| (default) | `medium` |

### Dependency Inference

```python
def infer_dependencies(task_number: int, category: str) -> list:
    deps = []
    
    # Infrastructure tasks have no dependencies
    if category == "infrastructure":
        return []
    
    # First non-infrastructure task depends on all infrastructure
    if task_number == first_non_infra_task:
        deps = [f"F{i:03d}" for i in infrastructure_tasks]
    
    # Security tasks depend on infrastructure
    if category == "security":
        deps.extend([f"F{i:03d}" for i in infrastructure_tasks])
    
    # UI tasks depend on their backend counterparts
    if category == "ui":
        # Find matching functional task
        matching = find_functional_task_for_ui(task)
        if matching:
            deps.append(matching.id)
    
    return deps
```

### Example Conversion

**Input (tasks.md)**:
```markdown
## Infrastructure
- [ ] 1. Project setup
  - [ ] 1.1 Create directory structure
  - [ ] 1.2 Configure build tools
  - [ ] 1.3 Set up linting
  - _Requirements: None_

## AuthService
- [ ] 2. Implement user registration
  - [ ] 2.1 Create User model
  - [ ] 2.2 Implement register() endpoint
  - [ ] 2.3 Add password hashing
  - [ ] 2.4 Return JWT token
  - _Requirements: 1.1, 1.2_

- [ ] 3. Implement user login
  - [ ] 3.1 Implement login() endpoint
  - [ ] 3.2 Validate credentials
  - [ ] 3.3 Return JWT token
  - _Requirements: 2.1, 2.2_
```

**Output (feature_list.json)**:
```json
{
  "project_name": "Project Name",
  "created": "2025-01-15T10:00:00Z",
  "last_updated": "2025-01-15T10:00:00Z",
  "total_features": 3,
  "passing_features": 0,
  "source_documents": {
    "blueprint": "docs/blueprint.md",
    "requirements": "docs/requirements.md",
    "design": "docs/design.md",
    "tasks": "docs/tasks.md",
    "validation": "docs/validation.md"
  },
  "features": [
    {
      "id": "F001",
      "category": "infrastructure",
      "priority": "critical",
      "description": "Project setup",
      "steps": [
        "Create directory structure",
        "Configure build tools",
        "Set up linting"
      ],
      "dependencies": [],
      "requirements_trace": [],
      "design_reference": null,
      "passes": false,
      "verified_at": null,
      "notes": ""
    },
    {
      "id": "F002",
      "category": "security",
      "priority": "critical",
      "description": "Implement user registration",
      "steps": [
        "Create User model",
        "Implement register() endpoint",
        "Add password hashing",
        "Return JWT token"
      ],
      "dependencies": ["F001"],
      "requirements_trace": ["1.1", "1.2"],
      "design_reference": "docs/design.md#authservice",
      "passes": false,
      "verified_at": null,
      "notes": ""
    },
    {
      "id": "F003",
      "category": "security",
      "priority": "high",
      "description": "Implement user login",
      "steps": [
        "Implement login() endpoint",
        "Validate credentials",
        "Return JWT token"
      ],
      "dependencies": ["F001", "F002"],
      "requirements_trace": ["2.1", "2.2"],
      "design_reference": "docs/design.md#authservice",
      "passes": false,
      "verified_at": null,
      "notes": ""
    }
  ]
}
```

---

## blueprint.md → init.sh

### Tech Stack Detection

Parse blueprint.md for technology mentions:

| Blueprint Mention | Init Script Action |
|-------------------|-------------------|
| "React", "Vite", "Next.js" | Add npm install + npm run dev |
| "FastAPI", "Flask", "Django" | Add pip install + python server |
| "Node.js", "Express" | Add npm install + npm start |
| "PostgreSQL" | Add database check/migration |
| "Redis" | Add Redis ping check |
| "Docker" | Add docker-compose up |

### Port Detection

| Technology | Default Port |
|------------|--------------|
| Vite | 5173 |
| Create React App | 3000 |
| Next.js | 3000 |
| FastAPI | 8000 |
| Flask | 5000 |
| Django | 8000 |
| Express | 3000 |
| PostgreSQL | 5432 |
| Redis | 6379 |

### Generated init.sh Template

```bash
#!/bin/bash
# Auto-generated from blueprint.md
# Tech stack: [detected technologies]

set -e
cd "$(dirname "$0")"

echo "🔄 Initializing [Project Name]..."

# Cleanup (ports from detection)
for port in [detected_ports]; do
    lsof -ti:$port 2>/dev/null | xargs kill -9 2>/dev/null || true
done

# [Backend section if detected]
# [Frontend section if detected]
# [Database section if detected]

# Health check
sleep 3
echo "✅ Ready"
echo "   [Service URLs based on detected tech]"
```

---

## requirements.md → Validation Helpers

### Acceptance Criteria Extraction

Parse requirements.md to build validation checklist:

```python
# Extract format:
# X.Y WHEN [trigger], THE **[Component]** SHALL [behavior].

criteria = [
    {
        "id": "1.1",
        "requirement": "User Registration",
        "component": "AuthService",
        "trigger": "user submits valid email and password",
        "behavior": "create a new user record AND return a JWT token",
        "testable": True
    },
    # ...
]
```

### Test Template Generation

For each criterion, generate test template:

```python
def test_req_1_1_user_registration():
    """
    Requirement 1.1: User Registration
    
    WHEN user submits valid email and password
    THE AuthService SHALL create a new user record
    AND return a JWT token
    """
    # Arrange
    email = "test@example.com"
    password = "SecurePass123"
    
    # Act
    result = auth_service.register(email, password)
    
    # Assert
    assert result.user is not None
    assert result.token is not None
    assert User.get_by_email(email) is not None
```

---

## design.md → Code Scaffolding

### Interface Extraction

Parse design.md component interfaces to generate code stubs:

**Input (design.md)**:
```markdown
### Component: AuthService
**Location**: `src/services/auth/`
**Interface**:
```python
class AuthService:
    async def register(self, email: str, password: str) -> User:
        """Create new user. Implements Req 1.1"""
    
    async def login(self, email: str, password: str) -> Token:
        """Authenticate user. Implements Req 2.1"""
```
```

**Output (src/services/auth/service.py)**:
```python
"""
AuthService - User authentication and authorization

Design Reference: docs/design.md#component-authservice
Requirements: 1.1, 1.2, 2.1, 2.2
"""

from typing import Optional
from ..models import User, Token


class AuthService:
    """Handle user authentication and authorization."""
    
    async def register(self, email: str, password: str) -> User:
        """
        Create new user account.
        
        Implements: Requirement 1.1
        Acceptance: WHEN user submits valid email and password,
                   SHALL create user record AND return JWT token
        
        Args:
            email: User's email address
            password: User's password (will be hashed)
            
        Returns:
            User: Created user object
            
        Raises:
            ValidationError: If email format invalid
            DuplicateError: If email already exists
        """
        raise NotImplementedError("TODO: Implement in Session C2")
    
    async def login(self, email: str, password: str) -> Token:
        """
        Authenticate user and return token.
        
        Implements: Requirement 2.1
        
        Args:
            email: User's email address
            password: User's password
            
        Returns:
            Token: JWT access token
            
        Raises:
            AuthenticationError: If credentials invalid
        """
        raise NotImplementedError("TODO: Implement in Session C3")
```

---

## Validation During Implementation

### Coverage Tracking

Maintain running count in feature_list.json:

```json
{
  "coverage_summary": {
    "total_requirements": 10,
    "requirements_covered": 4,
    "coverage_percentage": 40,
    "covered_list": ["1.1", "1.2", "2.1", "2.2"],
    "remaining_list": ["3.1", "3.2", "4.1", "4.2", "5.1", "5.2"]
  }
}
```

### Session Coverage Update

When marking feature as passing:

1. Get feature's `requirements_trace`
2. Add to `coverage_summary.covered_list`
3. Remove from `remaining_list`
4. Update percentages
5. Log in progress file

```markdown
### Requirements Coverage This Session
- ✓ Added: 3.1, 3.2
- Total covered: 6/10 (60%)
- Remaining: 4.1, 4.2, 5.1, 5.2
```
